<!doctype html>
<html>
	<head>
		<meta charset="utf-8"> 
		<title>查询结果</title>
		<style>
			a{text-decoration:none}
			a:hover{text-decoration:underline} 
		</style>
	<head>
<body>
	<table width="50%" border="1px">
			<tr><th>班级</th><th>姓名</th><th>得分</th><th>提交时间</th></tr>
		<?php
		$code=$_GET["class_query"];
		$std=$_GET["std_query"];
		
		echo "您的查询：";
		echo "班级: ".$code."   ,";
		echo "姓名: ".$std."<br>";
		
		
		$str1="select * from score where class_code=";
		$str2="select * from score where student=";
		
		if($std=="" && $code!="")
		{
			$search_str = $str1.$code;
		}
		else if($std!="" && $code=="")
		{
		$search_str = $str2."'{$std}'";
			
		}
		else if($std!="" && $code!="")
		{
		$search_str = $str1.$code." and student="."'{$std}'";
		}
		else
		{
			$search_str="select * from score";
		}
		//echo "<br>".$search_str."<br>";
		
		$sch = new PDO('mysql:host=localhost; dbname=dictations','root','');
		
		$row=$sch->query($search_str);
		
		foreach($row as $pt){
			?>
		<tr><td width="20%"><?=$pt['class_code']?></td><td width="20%"><?=$pt['student']?></td><td width="10%"><?=$pt['score']?></td><td width="50%"><?=$pt['date']?></td></tr>
	<?php }	?>
	
	</table>
	
	<center><font size=8><a href="teacher.php">返回</a></font></center>
	
</body>
</html>

