<?php
	$en=$_POST['en'];
	$cn=$_POST['cn'];

	if($en=="" || $cn=="")
	{
		echo '<script language="javascript">location.href="teacher.php"</script>';
	}
	
	$insert_str="INSERT INTO words(en,cn) value('$en','$cn')";
	try{
		$pdo=new PDO('mysql:host=localhost; dbname=dictations','root','');
		$cnt=$pdo->exec($insert_str);
		//echo "加入成功！";
		echo '<script language="javascript">location.href="teacher.php"</script>';
	}catch(PDOException $e){
		echo "加入失败！<br>".$e->getMessage();
	}
	$pdo=NULL;
?>