<?php

	if(isset($_COOKIE))
	{
		setcookie("name", "", time()-3600);
		setcookie("pswd","",time()-3600);
		setcookie("class_code","",time()-3600);
		setcookie("teacher","",time()-3600);
	}
	
	$name=$_POST['username'];
	$pswd=$_POST['password'];
	
	//echo $name;echo "<br>";
	//echo $pwsd;echo "<br>";
	
	setcookie("name",$name);
	setcookie("pswd",$pswd);
	
	$str="SELECT name,password,class_code FROM teachers";
	$str1="SELECT name,password,class_code,teacher FROM students";
	$check=0;
	
	try
		{
			$db=new PDO('mysql:host=localhost; dbname=authentication','root','');
			$row=$db->query($str);
			$row1=$db->query($str1);
		}catch(PDOException $ex ){ 
			echo "sorry! an error occured.<br>";
		} 
	foreach($row as $one){ 
		if($one["name"]== $name && $one["password"]==$pswd)
		{
			$check=1;
			setcookie("class_code",$one["class_code"]);
		}
	 } 
	 foreach($row1 as $one1){ 
		if($one1["name"]== $name && $one1["password"]==$pswd)
		{
			$check=2;
			setcookie("class_code",$one1["class_code"]);
			setcookie("teacher",$one1["teacher"]);
		}
	 } 
	
	//echo "check=$check"; 
	
	if($check==2)
	{
		//include("student.php");
		//echo "你是学生。<br>";
		echo '<script language="javascript">location.href="student.php"</script>';
		
	}
	else if($check==1)
	{
		//include("teacher.php");
		//echo "你是老师。<br>";
		 echo '<script language="javascript">location.href="teacher.php"</script>';
		
	}
	else if($check==0)
	{
		include("../html/wrong_pswd.html");
		//echo "用户名或密码错误，请重新输入。<br>";
	}
	else
	{
		include("../html/system_error.html");
		//echo "System error, plase try again!<br>";
	}
?>