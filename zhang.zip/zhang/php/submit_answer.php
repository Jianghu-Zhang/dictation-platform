<?php
	date_default_timezone_set('PRC');
	//echo $_GET["a1"];
	$stud=$_COOKIE['name'];
	$code=$_COOKIE['class_code'];
	
	$st = "select * from words";
	$sq = new PDO('mysql:host=localhost; dbname=dictations','root','');
	
	$row =$sq->query($st);
	$k=0;
	$score=0;
	foreach($row as $r){
		$k=$k+1;
		$str="a".$k;
		if($r['en']==$_GET[$str])
		{
			$score=$score+1;
		}
		//echo $r['en']."<br>";
	}
	

	$dat=date("e Y-m-d h:i:s A");
	
	$score_str="insert into score(student,class_code,score,date) value('$stud','$code','$score','$dat');";
	
	$sq->exec($score_str);
	
	$sq=NULL;
?>

<!doctype html>

<head>
	<meta charset="utf-8"> 
	<title>成功提交</title>
	<style>
		a{text-decoration:none}
		a:hover{text-decoration:underline} 
	</style>
</head>

<body>
	<center><font size=10>你已成功提交！点击 &nbsp <a href="student.php">返回</a> &nbsp 可查看得分</font></center>
	<br>
</body>