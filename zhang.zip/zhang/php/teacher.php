<!DOCTYPE html> 
<html>
<head>
	<meta charset="utf-8"> 
	<title>教师页面</title>
</head>
</html>

<?php
	//include("../html/top.html");
	include("../html/teacher.html");
	
?>