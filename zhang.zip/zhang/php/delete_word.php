<?php
	$id=$_POST['id'];

	if($id=="")
	{
		echo '<script language="javascript">location.href="teacher.php"</script>';
	}
	
	$str="delete from words where id={$id}";
	try{
		$pdo=new PDO('mysql:host=localhost; dbname=dictations','root','');
		$cnt=$pdo->query($str);
		echo '<script language="javascript">location.href="teacher.php"</script>';
	}catch(PDOException $e){
		echo "失败！<br>".$e->getMessage();
	}
	$pdo=NULL;
?>