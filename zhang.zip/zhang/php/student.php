<!DOCTYPE html> 
<html>
<head>
	<meta charset="utf-8"> 
	<title>学生页面</title>
</head>
</html>

<?php
	//include("../html/top.html");
	include("../html/student.html")
?>
