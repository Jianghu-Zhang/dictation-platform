<?php
	//include("yes.html");
	$name=$_POST['username'];
	$pswd=$_POST['password'];
	$code=$_POST['class_code'];
	
	//echo $name;echo "<br>";
	//echo $pswd;echo "<br>";
	//echo $code;echo "<br>";
	
	$str="SELECT name,class_code FROM teachers";
	$check=0;
	
	try
	{
		$db=new PDO('mysql:host=localhost; dbname=authentication','root','');
		$temp=$db->query($str);
		$db=NULL;
	}catch(PDOException $e ){ 
		include("../html/no.html");
		echo "发生错误。<br>".$e->getMessage();
	}
	
	foreach($temp as $ton){ 
		if($ton["class_code"]== $code )
		{
			$check=1;
			$teacher=$ton["name"];
		}
	}
	
	if($check==1)
	{
		//echo $name;echo $pswd;echo $code;echo $teacher;
		$insert_str="INSERT INTO students(name,password,class_code,teacher) value('$name','$pswd','$code','$teacher' )";
		try{
			$pdo=new PDO('mysql:host=localhost; dbname=authentication','root','');
			$cnt=$pdo->exec($insert_str);
			include("../html/yes.html");
		}catch(PDOException $e){
			include("../html/no.html");
			echo "注册失败，请重新注册！<br>".$e->getMessage();
		}
		$pdo=NULL;
	}else{
		include("../html/not_exist.html");
	}
?>